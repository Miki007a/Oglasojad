package Eads.model.exceptions;

public class InvalidUsernameOrPasswordException extends RuntimeException {
}

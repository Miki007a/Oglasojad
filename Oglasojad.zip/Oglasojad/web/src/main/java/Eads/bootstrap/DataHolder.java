package Eads.bootstrap;
import Eads.model.Role;
import Eads.service.UserService;
import Eads.model.User;
import Eads.service.CategoryService;
import Eads.service.OglasService;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Component
public class DataHolder {

    public static final String ADMIN = "admin";

    private final CategoryService categoryService;

    private final OglasService oglasService;

    public DataHolder(CategoryService categoryService, OglasService oglasService, UserService userService) {
        this.categoryService = categoryService;
        this.oglasService = oglasService;
        this.userService = userService;
    }

    private final UserService userService;




    @PostConstruct
    public void initData() {

       User user= userService.register("admin0","admin0","admin0","Михаил","Трајковиќ", Role.ROLE_ADMIN);
        User user1= userService.register("user0","user0","user0","Симон","Трајковиќ", Role.ROLE_USER);
        this.categoryService.create("Автомобили");
        this.categoryService.create("Живеалишта");
        this.categoryService.create("Работа");
        this.categoryService.create("Електроника");
        this.categoryService.create("Дом и семејство");
        this.categoryService.create("Услуги");
        List<String> cities=new ArrayList<>();
        cities.add("Скопје");
        cities.add("Битола");
        cities.add("Прилеп");
        cities.add("Охрид");
        cities.add("Велес");
        cities.add("Кавадарци");
        cities.add("Струмица");
        cities.add("Тетово");
        cities.add("Валандово");
        cities.add("Скопје");
        cities.add("Скопје");
        cities.add("Скопје");
        cities.add("Битола");
        cities.add("Прилеп");
        cities.add("Охрид");
        cities.add("Велес");
        cities.add("Кавадарци");
        cities.add("Струмица");
        cities.add("Тетово");
        cities.add("Валандово");
        cities.add("Скопје");
        cities.add("Скопје");



        for (int i = 0; i < 20; i++) {
            if (i<10){
                this.oglasService.create("Prodavam Seat Altea XL", 20.00 * i, LocalDate.now(), Stream.of(1L, i % 5L + 1).collect(Collectors.toList()),"-Proizvedeno vo Torslanda posleden model 100 % Sweden proizvod do najmalo strafce.\n" +
                        "-Mehanika promeneti bukvalno site potrosni materijali pred 2500 km (10.10.2023) vo ovlasten servis i podgotveno za dolga kilometraza bez nikakvi problemi.( 2500 Evra isklucivo originalni delovi).\n" +
                        "-Tehnicki kontrolen pregled vo ovlasten servis na 24.01.2024\n" +
                        "-100 % se funkcionalno, originalno i avtenticno.\n" +
                        "- Za tie sto neznaat model so full oprema (klimatronic, elektrika na site stakla, elektrika retrovizori, greaci na site sedista, cruse control, maglenki napred i nazad, zatemneti stakla itn).\n" +
                        "-Aktivno se upotrebuva sekojdnevno na kratki i dolgi relacii\n" +
                        "- Enterier delumno obnoven samo ostetenite delovi za da se zacuva avtenticnosta.\n" +
                        "-Karoserija originalna fabricka boja so mali grebanici\n" +
                        "-Premium gumi novi zimski\n" +
                        "-Premium akumulator nov prema upatsvo Volvo.\n" +
                        "-Unikatna Volvo karakteristicna voznja sigurnost i udobnost\n" +
                        "-Kilometraza 303500 km" ,cities.get(i),user.getUsername(),"/car2.jpg");

            }else{
                this.oglasService.create("Vw Golf 7.5 GTD 184 Ks -2017", 20.00 * i, LocalDate.now(), Stream.of(1L, i % 5L + 1).collect(Collectors.toList()), "Марка: VW\n" +
                        "Модел: GOLF\n" +
                        "Година: 2017\n" +
                        "Коњски сили: 184\n" +
                        "Менувач: manuel\n" +
                        "Број на седишта: 5\n" +
                        "Каросерија: HATCHBACK\n" +
                        "Километража: 190.000",cities.get(i),user1.getUsername(),"/car.jpeg");

            }
        }

}}
